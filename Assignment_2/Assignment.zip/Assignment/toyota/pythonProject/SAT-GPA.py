import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sea
df=pd.read_csv('SAT-GPA.csv')
print(df)
print(df.head(5))
print(df.tail(5))
print(df.describe())
df.info()
print(df.isna().sum())
radio=df['SAT']
Mistlamps=df['GPA']
plt.bar(radio,Mistlamps,color='red')
plt.scatter(radio,Mistlamps,color="green")
plt.show()
sea.pairplot(df)

plt.show()

plt.hist(radio)
plt.show()
plt.plot(radio, linestyle = 'dotted')
plt.show()